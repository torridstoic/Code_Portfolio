#include "PathSearch.h"
#include <Windows.h>

namespace fullsail_ai
{
	namespace algorithms
	{
#pragma region Helper Functions
		bool isGreaterHeuristic(PlannerNode* const& pLhs, PlannerNode* const& pRhs)
		{
			return (pLhs->heuristicCost > pRhs->heuristicCost);
		}

		bool PathSearch::areAdjacent(Tile* pTile, Tile* pSideTile)
		{
			if (NULL == pTile
				|| NULL == pSideTile
				|| 0 == pSideTile->getWeight())
			{
				return false;
			}

			const int row = pTile->getRow();
			const int col = pTile->getColumn();
			const int secondRow = pSideTile->getRow();
			const int secondCol = pSideTile->getColumn();
			if (abs(row - secondRow) > 1 || abs(col - secondCol) > 1)
			{
				return false;
			}

			if (row % 2 == 0) // even row
			{
				if (row != secondRow && secondCol > col)
				{
					return false;
				}
			}
			else // odd row
			{
				if (row != secondRow && col > secondCol)
				{
					return false;
				}
			}

			return true;
		}

		void PathSearch::updateDisplay(PlannerNode* pCurrPNode)
		{
#if 0
			pTileMap->resetTileDrawing();

			for (std::pair<SearchNode*, PlannerNode*> element : mVisitedNodes)
			{
				// FILL all visited tiles BLUE
				element.first->pTile->setFill(0xFF0000FF);
			}

			int colorVal = 0xFF;
			std::vector<PlannerNode*> vOpenNodes;
			pqOpenNodes.enumerate(vOpenNodes);
			//for (PlannerNode* pPNode : vOpenNodes)
			for (int i = vOpenNodes.size() - 1; i >= 0; --i)
			{
				// MARK all open tiles GREEN (gradient)
				vOpenNodes[i]->pSearchNode->pTile->setMarker(colorVal * 0x100 + 0xFF000000);
				colorVal = (colorVal > 10) ? (colorVal - 10) : 1;
			}

			if (!bSolutionFound)
			{
				for (Edge edge : pCurrPNode->pSearchNode->edges)
				{
					// OUTLINE all neighbors ORANGE
					edge.pEndpointSNode->pTile->setOutline(0xFFFFA000);
				}
			}

			for (PlannerNode* pWalkPNode = pCurrPNode;
				pWalkPNode->pParentPNode != nullptr;
				pWalkPNode = pWalkPNode->pParentPNode)
			{
				// ADD LINE from curr node to start (RED)
				pWalkPNode->pSearchNode->pTile->addLineTo(pWalkPNode->pParentPNode->pSearchNode->pTile, 0xFFFF0000);
			}
#endif
		}

		float PathSearch::estimate(Tile* pTile, Tile* pSecTile)
		{
			float x = abs(pTile->getXCoordinate() - pSecTile->getXCoordinate());
			float y = abs(pTile->getYCoordinate() - pSecTile->getYCoordinate());
			return (x*x + y*y);
		}
#pragma endregion
#pragma region Ctor/Dtor
		PathSearch::PathSearch() : pqOpenNodes(PriorityQueue<PlannerNode*>(isGreaterHeuristic))
		{
			shutdown(); // initializes all member variables
		}

		PathSearch::~PathSearch()
		{
			shutdown(); // frees all allocated memory
		}
#pragma endregion
#pragma region Public Functions
		void PathSearch::initialize(TileMap* _tileMap)
		{
			shutdown(); // resets all member variables

			pTileMap = _tileMap;
			const int mapRows = pTileMap->getRowCount();
			const int mapCols = pTileMap->getColumnCount();

			// Create SearchNodes and add to SearchGraph
			for (int row = 0; row < mapRows; ++row)
			{
				for (int col = 0; col < mapCols; ++col)
				{
					Tile* pCurrTile = pTileMap->getTile(row, col);
					if (NULL != pCurrTile && pCurrTile->getWeight() > 0)
					{
						mSearchGraph[pCurrTile] = new SearchNode(pCurrTile);
					}
				}
			}
			// Create Edges from new SearchNodes
			for (std::pair<Tile*, SearchNode*> element : mSearchGraph)
			{
				const int y = element.first->getRow();
				const int x = element.first->getColumn();

				for (int row = y - 1; row <= y + 1; ++row)
				{
					for (int col = x - 1; col <= x + 1; ++col)
					{
						Tile* pCurrTile = pTileMap->getTile(row, col);
						if (areAdjacent(element.first, pCurrTile))
						{
							element.second->edges.push_back(Edge(mSearchGraph[pCurrTile]));

							// Draw all edges
							element.first->addLineTo(pCurrTile, 0xFF0000FF);
						}
					}
				}
			}
		}

		void PathSearch::enter(int startRow, int startColumn, int goalRow, int goalColumn)
		{
			bSolutionFound = false;

			pGoalTile = pTileMap->getTile(goalRow, goalColumn);
			vSolutionPath.clear();
			//vSolutionPath.push_back(pGoalTile);

			SearchNode* pStartNode = mSearchGraph[pTileMap->getTile(startRow, startColumn)];
			PlannerNode* pStartPlanner = new PlannerNode(pStartNode);
			pStartPlanner->heuristicCost = estimate(pStartNode->pTile, pGoalTile);
			pqOpenNodes.push(pStartPlanner);
			mVisitedNodes[pStartNode] = pStartPlanner;

			// Update display
			updateDisplay(pqOpenNodes.front());
		}

		void PathSearch::update(long timeslice)
		{
			DWORD goalTime = GetTickCount() + timeslice;

			while (!pqOpenNodes.empty() && !bSolutionFound)
			{
				PlannerNode* pCurrPNode = pqOpenNodes.front();
				pqOpenNodes.pop();

				if (pCurrPNode->pSearchNode->pTile == pGoalTile)
				{
					bSolutionFound = true;
					for (PlannerNode* pWalkPNode = pCurrPNode;
						nullptr != pWalkPNode;
						pWalkPNode = pWalkPNode->pParentPNode)
					{
						// Build the solution path (vector) : finish to start
						vSolutionPath.push_back(pWalkPNode->pSearchNode->pTile);
					}
				}

				for (Edge edge : pCurrPNode->pSearchNode->edges)
				{
					SearchNode* pAdjNode = edge.pEndpointSNode;
					if (NULL == mVisitedNodes[pAdjNode])
					{
						// If node hasn't been Visited, add it to Visited&Open structs
						PlannerNode* pOpenPNode = new PlannerNode(pAdjNode);
						pOpenPNode->pParentPNode = pCurrPNode;
						pOpenPNode->heuristicCost = estimate(pAdjNode->pTile, pGoalTile);

						mVisitedNodes[pAdjNode] = pOpenPNode;
						pqOpenNodes.push(pOpenPNode);
					}
				}

				updateDisplay(pCurrPNode);

				if (GetTickCount() >= goalTime)
				{
					// Break out if we've passed the timeslice
					break;
				}
			}
		}

		void PathSearch::exit()
		{
			for (std::pair<SearchNode*, PlannerNode*> element : mVisitedNodes)
			{
				delete element.second;
			}
			mVisitedNodes.clear();
			pqOpenNodes.clear();
		}

		void PathSearch::shutdown()
		{
			exit();

			for (std::pair<Tile*, SearchNode*> element : mSearchGraph)
			{
				delete element.second;
			}
			mSearchGraph.clear();

			pTileMap = nullptr;
			pGoalTile = nullptr;
			bSolutionFound = false;
		}

		bool PathSearch::isDone() const
		{
			return bSolutionFound;
		}

		std::vector<Tile const*> const PathSearch::getSolution() const
		{
			return vSolutionPath;
		}
#pragma endregion
	}
}  // namespace fullsail_ai::algorithms

